<?php
/**
 * Plugin Name:       Adecash Adblock Plugin V2
 * Description:       Allows easy integration of Adcash Adblock tag.
 * Version:           2.0.0
 */

defined('ABSPATH') or die();

add_action('admin_menu', 'adcash_adblock_add_admin_menu');
add_action('admin_init', 'adcash_adblock_settings_init');
add_action('wp_enqueue_scripts', 'adcash_adblock_script_render');
add_action('updated_option', 'adcash_adblock_on_option_update', 10, 3);

function adcash_adblock_script_render() {
	$tag = adcash_adblock_get_tag_to_render();

	if (!empty($tag)) {
		?>
		<?php echo $tag; ?>
		<?php
	}
}

function adcash_adblock_on_option_update($old_value, $value, $option) {
	if (is_array($option)) {
		if (array_key_exists('adcash_adblock_cache', $option)) {
			delete_transient('adcash_adblock_tag_cache');
		}
	}
}

function adcash_adblock_get_tag_to_render() {
	$settings = get_option('adcash_adblock_settings');
	if (empty($settings)) {
		return '';
	}

	$cacheTTL = isset($settings['adcash_adblock_cache']) ? $settings['adcash_adblock_cache'] : null;

	if (!$cacheTTL) {
		return '';
	}

	$cached = get_transient('adcash_adblock_tag_cache');
	if (!$cached) {
		$response = wp_remote_get( "https://youradexchange.com/ad/s2sadblock.php?v=3");

		$body = wp_remote_retrieve_body($response);
		if (!$body) {
			return '';
		}

		$test = set_transient('adcash_adblock_tag_cache', $body, intval($cacheTTL) * 60);
		$cached = $body;
	}

	return $cached;
}

function adcash_adblock_add_admin_menu() {
	add_options_page('adcash_adblock', 'Adcash Adblock', 'manage_options', 'adcash_adblock', 'adcash_adblock_options_page');
}

function adcash_adblock_settings_init() {
	register_setting('pluginPage', 'adcash_adblock_settings');

	add_settings_section(
		'adcash_adblock_pluginPage_section',
		__( 'Adcach Adblock Plugin Settings', 'adcash.com' ),
		'adcash_adblock_settings_section_callback',
		'pluginPage'
	);

	add_settings_field(
		'adcash_adblock_cache',
		__( 'Cache Period in minutes', 'adcash.com' ),
		'adcash_adblock_cache_render',
		'pluginPage',
		'adcash_adblock_pluginPage_section'
	);
}

function adcash_adblock_cache_render() {
	$options = get_option('adcash_adblock_settings');
	?>
	<input type='number' name='adcash_adblock_settings[adcash_adblock_cache]' value='<?php echo (isset($options['adcash_adblock_cache']) ? $options['adcash_adblock_cache'] : 60); ?>'>
	<?php
}

function adcash_adblock_settings_section_callback() {
	echo __('Please setup your preferred cache period in minutes.', 'adcash.com');
}

function adcash_adblock_options_page() {
	?>
	<form action='options.php' method='post'>

		<h2>Adcash Adblock Options</h2>

		<?php
		settings_fields('pluginPage');
		do_settings_sections('pluginPage');
		submit_button();
		?>

	</form>
	<?php
}

function adcash_adblock_deactivate() {
	delete_transient('adcash_adblock_tag_cache');
}
register_deactivation_hook( __FILE__, 'adcash_adblock_deactivate' );

