<?php

if (!defined('WP_UNINSTALL_PLUGIN')) {
    die;
}

delete_option('adcash_adblock_settings');
